import React from 'react'

export default function Copywrite() {
  return (
    <div>
       <footer>
    <div className="center">
        Copyrights &copy;www.myOnlineDressDiv.com.All rights reserved! creator-SUMAN VASTRAKAR
    </div>
</footer>
    </div>
  )
}

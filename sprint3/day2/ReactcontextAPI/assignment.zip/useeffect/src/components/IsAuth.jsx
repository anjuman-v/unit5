import { useContext } from "react";
import { Navbar } from "./Navbar";

export const Auth = ()=> {
return (
   <nav>
       <h1>Number of item</h1>
   </nav> 
)
}
import { useContext } from "react";

export const Button = ()=>{

    return(
        <button>Button</button>
    )
}
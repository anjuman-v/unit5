import { TODOS } from "./action";

const initialState = {
    todo:[],

};

 const reducer = (store = initialState,{ type, payload }) =>{
    console.log(store)
    
    switch(type){
        // case TODOS:
            // return {
            //     ...store,todo:[...store.todo,payload]
            // }
            default :
            return store
        }


}

export {reducer}



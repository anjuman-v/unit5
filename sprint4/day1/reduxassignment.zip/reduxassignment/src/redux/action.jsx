
export const TODOS = "TODOS";

export const addTodo = (todo) => ({type:TODOS, payload:todo})
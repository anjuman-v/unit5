import React, { useState } from "react";
 import { useSelector, useDispatch } from "react-redux";
import {addTodo} from '../redux/action'




 const Todos = () => {

  const [todo, setTodo] = useState("")
  
  const todoselect = useSelector((store)=> store.todo) || []
  
  const dispatch = useDispatch()
  //set data
 const handleSubmit = () =>{
  dispatch(addTodo(todo))
 }
 console.log("todo",todo)

    return (
    <div className="addTodos">
      <input
        type="text"
       onChange={(e) =>{setTodo(e.target.value)}}
        className="todo-input"
       
      />

      <button className="add-btn"
        onClick={handleSubmit}
      >
          add
          </button>
          
         <div>
           {todoselect.map((e)=>{

              return(

                <h3>
                  {e}
                </h3>
              )


           })}
           </div> 
         

    </div>
  )
}

export default Todos
